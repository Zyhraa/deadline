<?php

include '../../connection.php';
  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
	$title = mysqli_real_escape_string($con, $_POST['title']);
  	$image_text = mysqli_real_escape_string($con, $_POST['image_text']);
    $rating = mysqli_real_escape_string($con, $_POST['rating']);

  	// image file directory
  	$target = "../animecover/".basename($image);

  	$sql = "INSERT INTO anime (title, img, synopsis, rating) VALUES ('$title', '$image', '$image_text', '$rating')";
  	// execute query
  	mysqli_query($con, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";

		  header("location: show.php");
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
