<?php
include '../../connection.php'; 

$result = mysqli_query($con, "SELECT * FROM anime");
while ($row = mysqli_fetch_array($result)) { ?>

<link rel="stylesheet" type="text/css" href="style.css">

	<div id="kotak">
		<h1><?=$row['title']?></h1>	
		<img src="../animecover/<?=$row['img']?>">
		<p><?=$row['synopsis']?></p>
		<input type="button" name="details" value="DETAILS">
	</div>
<?php } ?>
	
</body>
</html>
