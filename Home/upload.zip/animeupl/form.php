
<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>
</head>

<body>
<div id="content">

  <form method="POST" action="upload.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">

	<div>judulnya
		<input type="text" name="title" placeholder="title">
	</div>
  	<div>gambar
  	  <input type="file" name="image">
  	</div>
  	<div>sipnosis
      <textarea id="text" cols="40" rows="4" name="image_text" placeholder="Say something about this image..."></textarea>
  	</div>
	  <div><input type="number" name="rating" id=""></div>
  	<div>
  		<button type="submit" name="upload">POST</button>
  	</div>
  </form>
</div>
</body>
</html>