<?php

include 'conn.php';
  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
	$jdl = mysqli_real_escape_string($conn, $_POST['title']);
  	$prcs = mysqli_real_escape_string($conn, $_POST['price']);

  	// image file directory
  	$target = "catalog/".basename($image);

  	$sql = "INSERT INTO merchs (namecata, price, img) VALUES ('$jdl', '$prcs', '$image')";
  	// execute query
  	mysqli_query($conn, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";

		  header("location: show.php");
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
