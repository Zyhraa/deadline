<?php
include 'conn.php'; 

$result = mysqli_query($conn, "SELECT * FROM merchs");
while ($row = mysqli_fetch_array($result)) { ?>

<link rel="stylesheet" type="text/css" href="style.css">

	<div id="kotak">
		<img src="catalog/<?=$row['img']?>">
		<h1><?=$row['namecata']?></h1>
		<p><?=$row['price']?></p>
		<input type="submit" value="BUY">
		<input type="button" name="details" value="DETAILS">
	</div>
<?php } ?>
	
</body>
</html>
